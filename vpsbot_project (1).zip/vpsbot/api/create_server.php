<?php
// OpenStack server creation logic
